import React from "react";
import SearchFood from "../SearchFood/SearchFood"

export default function Search() {
  return (
    <div>
      <SearchFood/>
    </div>
  );
}
